SELECT COALESCE(thn_byr, 'TOTAL') AS thn_byr, 
		COALESCE(id_pelanggan, 'SUB TOTAL') AS id_pelanggan,
		COALESCE(id_produk, 'SUB TOTAL') AS id_produk,
		SUM(jml_byr) AS jml_byr 
FROM `sales` 
GROUP BY thn_byr, id_pelanggan, id_produk WITH ROLLUP