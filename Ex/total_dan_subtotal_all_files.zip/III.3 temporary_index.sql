SET @idx=0, @idx2=0;

SELECT SUM(jml_byr) FROM sales INTO @total;
SELECT thn_byr, id_pelanggan, id_produk, jml_byr, rasio
		,@idx:=@idx+1 as idx
		,
				(      
					SELECT CONCAT(rnum, '-', thn_byr)
					FROM
					(
						SELECT thn_byr, @idx2:=@idx2+1 as rnum
						 FROM 
						 (
							 SELECT  thn_byr FROM sales GROUP BY thn_byr DESC, id_pelanggan, id_produk
						 ) as tmp
					) as tmp
					WHERE rnum > @idx AND rnum < @idx+2   
				)
			as idx_next_year
FROM (
    SELECT thn_byr, id_pelanggan, id_produk
			,SUM(jml_byr) as jml_byr
			,ROUND(SUM(jml_byr)/@total*100, 2) as rasio
    FROM sales
    GROUP BY thn_byr, id_pelanggan, id_produk
    ORDER BY thn_byr DESC, id_pelanggan
) new_sales