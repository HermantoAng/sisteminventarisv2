SELECT thn_byr, id_pelanggan, id_produk, jml_byr
FROM
(
	SELECT COALESCE(thn_byr, 0) as thn_byr,
			COALESCE(id_pelanggan, 'SUB TOTAL') AS id_pelanggan,
			COALESCE(id_produk, 'SUB TOTAL') AS id_produk,
			SUM(jml_byr) AS jml_byr
    FROM sales
    GROUP BY thn_byr, id_pelanggan, id_produk WITH ROLLUP
) as sales
ORDER BY thn_byr DESC, id_pelanggan, jml_byr