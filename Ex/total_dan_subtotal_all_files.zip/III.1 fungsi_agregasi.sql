SELECT SUM(jml_byr) FROM sales INTO @total;

SELECT thn_byr, id_pelanggan, id_produk, SUM(jml_byr) as jml_byr, ROUND(SUM(jml_byr)/@total*100, 2) as rasio
FROM sales
GROUP BY thn_byr, id_pelanggan, id_produk
	UNION
SELECT thn_byr, CONCAT(id_pelanggan, '-SUB TOTAL'), id_produk, SUM(jml_byr) as jml_byr, ROUND(SUM(jml_byr)/@total*100, 2) as rasio
FROM sales
GROUP BY thn_byr, id_pelanggan
	UNION
SELECT thn_byr, CONCAT('TOTAL ', thn_byr), id_produk, SUM(jml_byr) as jml_byr, ROUND(SUM(jml_byr)/@total*100, 2) as rasio
FROM sales
GROUP BY thn_byr
	UNION
SELECT null, 'GRAND TOTAL', null, ROUND(@total), '100.00'
ORDER BY thn_byr DESC, id_pelanggan, jml_byr DESC